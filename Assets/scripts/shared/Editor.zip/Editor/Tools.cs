using System.Diagnostics;
using System.IO;
using UnityEditor;

public class Tools:Editor
{
    [MenuItem("RTools/compare")]
    public static void Compare()
    {
        var a = new FileInfo(AssetDatabase.GetAssetPath(Selection.gameObjects[0]));
        var b= new FileInfo(AssetDatabase.GetAssetPath(Selection.gameObjects[1]));
        Process.Start(@"C:\Program Files (x86)\Microsoft Visual Studio 11.0\Common7\IDE\devenv.exe", string.Format("/diff \"{0}\" \"{1}\"", a.FullName, b.FullName));
    }
}